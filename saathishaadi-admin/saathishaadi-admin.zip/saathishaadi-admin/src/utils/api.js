const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export const api = async (endpoint, options = {}, token = null) => {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const res = await fetch(`${BASE_URL}${endpoint}`, { headers, ...options });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'API Error');
  return data;
};

export const adminAPI = (token) => ({
  login: (creds) => api('/admin/login', { method: 'POST', body: JSON.stringify(creds) }),
  dashboard: () => api('/admin/dashboard', {}, token),
  getUsers: (params = '') => api(`/admin/users${params}`, {}, token),
  blockUser: (id) => api(`/admin/users/${id}/block`, { method: 'PUT' }, token),
  unblockUser: (id) => api(`/admin/users/${id}/unblock`, { method: 'PUT' }, token),
  deleteUser: (id) => api(`/admin/users/${id}`, { method: 'DELETE' }, token),
  getAds: () => api('/admin/ads', {}, token),
  createAd: (data) => api('/admin/ads', { method: 'POST', body: JSON.stringify(data) }, token),
  updateAd: (id, data) => api(`/admin/ads/${id}`, { method: 'PUT', body: JSON.stringify(data) }, token),
  deleteAd: (id) => api(`/admin/ads/${id}`, { method: 'DELETE' }, token),
});
