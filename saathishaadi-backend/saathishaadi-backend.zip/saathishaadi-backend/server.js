const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const server = http.createServer(app);

// ─── CORS ───────────────────────────────────────────────────────
const allowedOrigins = [
  process.env.FRONTEND_URL || 'http://localhost:3000',
  process.env.ADMIN_URL || 'http://localhost:3001',
  'http://localhost:3000',
  'http://localhost:3001',
];

app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) callback(null, true);
    else callback(new Error('Not allowed by CORS'));
  },
  credentials: true,
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─── STATIC FILES (uploads) ──────────────────────────────────────
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ─── ROUTES ──────────────────────────────────────────────────────
app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/proposals', require('./routes/proposals'));
app.use('/api/messages', require('./routes/messages'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/ads', require('./routes/ads'));

// Health check
app.get('/health', (req, res) => res.json({ status: 'OK', time: new Date().toISOString() }));
app.get('/', (req, res) => res.json({ message: 'SaathiShaadi API Running 🕉️' }));

// ─── SOCKET.IO ───────────────────────────────────────────────────
const io = new Server(server, {
  cors: {
    origin: allowedOrigins,
    methods: ['GET', 'POST'],
    credentials: true,
  },
});

const jwt = require('jsonwebtoken');
const User = require('./models/User');

// Online users map: userId -> socketId
const onlineUsers = new Map();

io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('Auth token missing'));
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('_id name');
    if (!user) return next(new Error('User not found'));
    socket.user = user;
    next();
  } catch (err) {
    next(new Error('Invalid token'));
  }
});

io.on('connection', (socket) => {
  const userId = socket.user._id.toString();
  onlineUsers.set(userId, socket.id);
  console.log(`✅ ${socket.user.name} connected [${socket.id}]`);

  // Notify others this user is online
  socket.broadcast.emit('user_online', userId);

  // ── CHAT ──────────────────────────────────────
  socket.on('join_chat', ({ otherUserId }) => {
    const room = [userId, otherUserId].sort().join('_');
    socket.join(room);
  });

  socket.on('send_message', ({ receiverId, message }) => {
    const room = [userId, receiverId].sort().join('_');
    socket.to(room).emit('receive_message', message);
  });

  socket.on('typing', ({ receiverId }) => {
    const receiverSocket = onlineUsers.get(receiverId);
    if (receiverSocket) {
      io.to(receiverSocket).emit('typing', userId);
    }
  });

  // ── CALLS (WebRTC Signaling) ──────────────────
  socket.on('call_user', ({ userToCall, signal, callType }) => {
    const targetSocket = onlineUsers.get(userToCall);
    if (targetSocket) {
      io.to(targetSocket).emit('incoming_call', {
        from: userId,
        fromName: socket.user.name,
        signal,
        callType,
      });
    } else {
      socket.emit('call_failed', { message: 'User offline hai' });
    }
  });

  socket.on('answer_call', ({ to, signal }) => {
    const targetSocket = onlineUsers.get(to);
    if (targetSocket) {
      io.to(targetSocket).emit('call_accepted', { signal });
    }
  });

  socket.on('end_call', ({ to }) => {
    const targetSocket = onlineUsers.get(to);
    if (targetSocket) {
      io.to(targetSocket).emit('call_ended');
    }
  });

  socket.on('ice_candidate', ({ to, candidate }) => {
    const targetSocket = onlineUsers.get(to);
    if (targetSocket) {
      io.to(targetSocket).emit('ice_candidate', { from: userId, candidate });
    }
  });

  // ── DISCONNECT ────────────────────────────────
  socket.on('disconnect', () => {
    onlineUsers.delete(userId);
    socket.broadcast.emit('user_offline', userId);
    console.log(`❌ ${socket.user.name} disconnected`);
  });
});

// ─── MONGOOSE ────────────────────────────────────────────────────
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/saathishaadi';

mongoose.connect(MONGO_URI)
  .then(() => {
    console.log('✅ MongoDB connected');
    const PORT = process.env.PORT || 5000;
    server.listen(PORT, () => {
      console.log(`🚀 SaathiShaadi backend running on port ${PORT}`);
      console.log(`📡 Socket.IO ready`);
    });
  })
  .catch((err) => {
    console.error('❌ MongoDB connection failed:', err.message);
    process.exit(1);
  });

// ─── ERROR HANDLER ───────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({ message: err.message || 'Server error' });
});

module.exports = { app, server };
