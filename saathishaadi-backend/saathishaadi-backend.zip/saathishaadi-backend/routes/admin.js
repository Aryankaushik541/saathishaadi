const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Proposal = require('../models/Proposal');
const Message = require('../models/Message');
const Advertisement = require('../models/Advertisement');
const { protect, adminOnly } = require('../middleware/auth');
const jwt = require('jsonwebtoken');

// POST /api/admin/login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const ADMIN_USER = process.env.ADMIN_USERNAME || 'admin';
    const ADMIN_PASS = process.env.ADMIN_PASSWORD || 'saathishaadi@admin2025';

    if (username !== ADMIN_USER || password !== ADMIN_PASS) {
      return res.status(401).json({ message: 'Galat username ya password' });
    }

    // Find or create admin user
    let admin = await User.findOne({ isAdmin: true });
    if (!admin) {
      admin = await User.create({
        phone: '9000000000', name: 'Admin', age: 30,
        gender: 'Male', religion: 'Hindu', isAdmin: true,
      });
    }

    const token = jwt.sign({ id: admin._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, admin: { _id: admin._id, name: admin.name, isAdmin: true } });
  } catch (err) {
    res.status(500).json({ message: 'Admin login error' });
  }
});

// All routes below require admin
router.use(protect, adminOnly);

// GET /api/admin/dashboard
router.get('/dashboard', async (req, res) => {
  try {
    const [totalUsers, activeUsers, totalProposals, acceptedProposals, totalMessages, blockedUsers] =
      await Promise.all([
        User.countDocuments({ isAdmin: false }),
        User.countDocuments({ isAdmin: false, isBlocked: false }),
        Proposal.countDocuments(),
        Proposal.countDocuments({ status: 'accepted' }),
        Message.countDocuments(),
        User.countDocuments({ isBlocked: true }),
      ]);

    // New users this week
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const newUsersThisWeek = await User.countDocuments({ isAdmin: false, createdAt: { $gte: weekAgo } });

    // Gender split
    const maleCnt = await User.countDocuments({ gender: 'Male', isAdmin: false });
    const femaleCnt = await User.countDocuments({ gender: 'Female', isAdmin: false });

    // Religion breakdown
    const religionStats = await User.aggregate([
      { $match: { isAdmin: false } },
      { $group: { _id: '$religion', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
    ]);

    // District breakdown
    const districtStats = await User.aggregate([
      { $match: { isAdmin: false, district: { $ne: '' } } },
      { $group: { _id: '$district', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 10 },
    ]);

    res.json({
      totalUsers, activeUsers, totalProposals, acceptedProposals,
      totalMessages, blockedUsers, newUsersThisWeek,
      maleCnt, femaleCnt, religionStats, districtStats,
    });
  } catch (err) {
    res.status(500).json({ message: 'Dashboard error' });
  }
});

// GET /api/admin/users
router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 20, search, gender, religion, isBlocked } = req.query;
    const query = { isAdmin: false };
    if (search) query.$or = [
      { name: { $regex: search, $options: 'i' } },
      { phone: { $regex: search, $options: 'i' } },
    ];
    if (gender) query.gender = gender;
    if (religion) query.religion = religion;
    if (isBlocked !== undefined) query.isBlocked = isBlocked === 'true';

    const skip = (Number(page) - 1) * Number(limit);
    const [users, total] = await Promise.all([
      User.find(query).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      User.countDocuments(query),
    ]);
    res.json({ users, total, totalPages: Math.ceil(total / Number(limit)) });
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

// PUT /api/admin/users/:id/block
router.put('/users/:id/block', async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id, { isBlocked: true }, { new: true }
    );
    res.json({ message: 'User block kar diya gaya', user });
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

// PUT /api/admin/users/:id/unblock
router.put('/users/:id/unblock', async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id, { isBlocked: false }, { new: true }
    );
    res.json({ message: 'User unblock kar diya gaya', user });
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

// DELETE /api/admin/users/:id
router.delete('/users/:id', async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    await Proposal.deleteMany({ $or: [{ sender: req.params.id }, { receiver: req.params.id }] });
    await Message.deleteMany({ $or: [{ sender: req.params.id }, { receiver: req.params.id }] });
    res.json({ message: 'User delete kar diya gaya' });
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

// GET /api/admin/ads
router.get('/ads', async (req, res) => {
  try {
    const ads = await Advertisement.find().sort({ createdAt: -1 });
    res.json(ads);
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

// POST /api/admin/ads
router.post('/ads', async (req, res) => {
  try {
    const ad = await Advertisement.create(req.body);
    res.status(201).json(ad);
  } catch (err) {
    res.status(500).json({ message: 'Error creating ad' });
  }
});

// PUT /api/admin/ads/:id
router.put('/ads/:id', async (req, res) => {
  try {
    const ad = await Advertisement.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(ad);
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

// DELETE /api/admin/ads/:id
router.delete('/ads/:id', async (req, res) => {
  try {
    await Advertisement.findByIdAndDelete(req.params.id);
    res.json({ message: 'Ad delete kar diya' });
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

module.exports = router;
