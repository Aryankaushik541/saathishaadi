const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Proposal = require('../models/Proposal');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');

// GET /api/users — Browse profiles with filters
router.get('/', protect, async (req, res) => {
  try {
    const { religion, gender, minAge, maxAge, district, caste, page = 1, limit = 12 } = req.query;
    const query = { isBlocked: false, _id: { $ne: req.user._id } };

    if (religion) query.religion = religion;
    if (gender) query.gender = gender;
    if (district) query.district = district;
    if (caste) query.caste = caste;
    if (minAge || maxAge) {
      query.age = {};
      if (minAge) query.age.$gte = Number(minAge);
      if (maxAge) query.age.$lte = Number(maxAge);
    }

    const skip = (Number(page) - 1) * Number(limit);
    const total = await User.countDocuments(query);
    const users = await User.find(query)
      .select('-phone -__v')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));

    res.json({ users, total, totalPages: Math.ceil(total / Number(limit)), page: Number(page) });
  } catch (err) {
    res.status(500).json({ message: 'Error loading users' });
  }
});

// GET /api/users/:id — Get single user profile
router.get('/:id', protect, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-__v');
    if (!user || user.isBlocked) return res.status(404).json({ message: 'User nahi mila' });

    // Hide phone unless it's own profile or accepted proposal
    if (req.params.id !== req.user._id.toString()) {
      const accepted = await Proposal.findOne({
        status: 'accepted',
        $or: [
          { sender: req.user._id, receiver: user._id },
          { sender: user._id, receiver: req.user._id },
        ],
      });
      if (!accepted) {
        const userObj = user.toObject();
        userObj.phone = '**********';
        return res.json(userObj);
      }
    }
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

// PUT /api/users/profile — Update own profile
router.put('/profile', protect, upload.single('photo'), async (req, res) => {
  try {
    const { name, age, religion, caste, district, profession, bio } = req.body;
    const updates = {};
    if (name) updates.name = name;
    if (age) updates.age = Number(age);
    if (religion) updates.religion = religion;
    if (caste !== undefined) updates.caste = caste;
    if (district !== undefined) updates.district = district;
    if (profession !== undefined) updates.profession = profession;
    if (bio !== undefined) updates.bio = bio;
    if (req.file) updates.photo = req.file.filename;

    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true }).select('-__v');
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Update error' });
  }
});

module.exports = router;
