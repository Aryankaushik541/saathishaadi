const express = require('express');
const router = express.Router();
const Message = require('../models/Message');
const Proposal = require('../models/Proposal');
const { protect } = require('../middleware/auth');

// Check if two users have an accepted proposal
const hasAcceptedProposal = async (userId1, userId2) => {
  return await Proposal.findOne({
    status: 'accepted',
    $or: [
      { sender: userId1, receiver: userId2 },
      { sender: userId2, receiver: userId1 },
    ],
  });
};

// GET /api/messages/conversations — All conversations
router.get('/conversations', protect, async (req, res) => {
  try {
    // Find all users this person has messaged or received messages from
    const messages = await Message.find({
      $or: [{ sender: req.user._id }, { receiver: req.user._id }],
    })
      .sort({ createdAt: -1 })
      .populate('sender receiver', 'name photo gender district age');

    // Unique conversations
    const convMap = new Map();
    messages.forEach((msg) => {
      const other = msg.sender._id.toString() === req.user._id.toString() ? msg.receiver : msg.sender;
      const key = other._id.toString();
      if (!convMap.has(key)) {
        convMap.set(key, { user: other, lastMessage: msg });
      }
    });

    res.json(Array.from(convMap.values()));
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

// GET /api/messages/:userId — Conversation with a user
router.get('/:userId', protect, async (req, res) => {
  try {
    const allowed = await hasAcceptedProposal(req.user._id, req.params.userId);
    if (!allowed) return res.status(403).json({ message: 'Chat ke liye proposal accept hona chahiye' });

    const messages = await Message.find({
      $or: [
        { sender: req.user._id, receiver: req.params.userId },
        { sender: req.params.userId, receiver: req.user._id },
      ],
    }).sort({ createdAt: 1 });

    // Mark as read
    await Message.updateMany(
      { sender: req.params.userId, receiver: req.user._id, read: false },
      { read: true }
    );

    res.json(messages);
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

// POST /api/messages — Send message
router.post('/', protect, async (req, res) => {
  try {
    const { receiverId, content } = req.body;
    if (!receiverId || !content) return res.status(400).json({ message: 'Receiver aur content required hain' });

    const allowed = await hasAcceptedProposal(req.user._id, receiverId);
    if (!allowed) return res.status(403).json({ message: 'Pehle proposal accept karwana hoga' });

    const message = await Message.create({ sender: req.user._id, receiver: receiverId, content });
    res.status(201).json(message);
  } catch (err) {
    res.status(500).json({ message: 'Error sending message' });
  }
});

module.exports = router;
