const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const OTP = require('../models/OTP');
const upload = require('../middleware/upload');

// Generate JWT
const generateToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '30d' });

// Generate 6-digit OTP
const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// POST /api/auth/send-otp
router.post('/send-otp', async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone || phone.length !== 10) {
      return res.status(400).json({ message: '10 digit mobile number daalen' });
    }

    // Delete old OTPs for this phone
    await OTP.deleteMany({ phone });

    const otp = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 min

    await OTP.create({ phone, otp, expiresAt });

    // In production, send SMS via MSG91 / Textlocal:
    // await sendSMS(phone, `SaathiShaadi OTP: ${otp}. Valid 10 min.`);

    console.log(`📱 OTP for ${phone}: ${otp}`); // Dev only

    res.json({ message: 'OTP bhej diya gaya', phone });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'OTP send karne mein error' });
  }
});

// POST /api/auth/verify-otp  (Login)
router.post('/verify-otp', async (req, res) => {
  try {
    const { phone, otp } = req.body;
    if (!phone || !otp) return res.status(400).json({ message: 'Phone aur OTP required hain' });

    // Dev mode: accept 123456
    if (otp !== '123456') {
      const otpRecord = await OTP.findOne({ phone, used: false }).sort({ createdAt: -1 });
      if (!otpRecord) return res.status(400).json({ message: 'OTP nahi mila. Dobara bhejein.' });
      if (new Date() > otpRecord.expiresAt) return res.status(400).json({ message: 'OTP expire ho gaya' });
      if (otpRecord.otp !== otp) return res.status(400).json({ message: 'Galat OTP' });
      otpRecord.used = true;
      await otpRecord.save();
    }

    const user = await User.findOne({ phone });
    if (!user) return res.status(404).json({ message: 'Phone registered nahi hai. Pehle register karein.' });
    if (user.isBlocked) return res.status(403).json({ message: 'Account block hai. Admin se contact karein.' });

    user.lastSeen = new Date();
    await user.save();

    res.json({ token: generateToken(user._id), user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Login error' });
  }
});

// POST /api/auth/register
router.post('/register', upload.single('photo'), async (req, res) => {
  try {
    const { phone, otp, name, age, gender, religion, caste, district, profession, bio } = req.body;

    if (!phone || !name || !age || !gender || !religion) {
      return res.status(400).json({ message: 'Required fields missing' });
    }

    // Verify OTP (dev: 123456)
    if (otp !== '123456') {
      const otpRecord = await OTP.findOne({ phone, used: false }).sort({ createdAt: -1 });
      if (!otpRecord || new Date() > otpRecord.expiresAt || otpRecord.otp !== otp) {
        return res.status(400).json({ message: 'Invalid ya expired OTP' });
      }
      otpRecord.used = true;
      await otpRecord.save();
    }

    // Check if already registered
    const existing = await User.findOne({ phone });
    if (existing) {
      // Update existing user and return token
      Object.assign(existing, { name, age: Number(age), gender, religion, caste, district, profession, bio });
      if (req.file) existing.photo = req.file.filename;
      await existing.save();
      return res.json({ token: generateToken(existing._id), user: existing });
    }

    const userData = { phone, name, age: Number(age), gender, religion, caste, district, profession, bio };
    if (req.file) userData.photo = req.file.filename;

    const user = await User.create(userData);
    res.status(201).json({ token: generateToken(user._id), user });
  } catch (err) {
    console.error(err);
    if (err.code === 11000) return res.status(400).json({ message: 'Phone number already registered hai' });
    res.status(500).json({ message: 'Registration error' });
  }
});

module.exports = router;
