const express = require('express');
const router = express.Router();
const Proposal = require('../models/Proposal');
const User = require('../models/User');
const { protect } = require('../middleware/auth');

// POST /api/proposals — Send proposal
router.post('/', protect, async (req, res) => {
  try {
    const { receiverId, message } = req.body;
    if (!receiverId) return res.status(400).json({ message: 'Receiver ID required' });
    if (receiverId === req.user._id.toString()) {
      return res.status(400).json({ message: 'Khud ko proposal nahi bhej sakte' });
    }

    const receiver = await User.findById(receiverId);
    if (!receiver || receiver.isBlocked) return res.status(404).json({ message: 'User nahi mila' });

    // Check if proposal already exists
    const existing = await Proposal.findOne({ sender: req.user._id, receiver: receiverId });
    if (existing) return res.status(400).json({ message: 'Proposal pehle se bheja ja chuka hai' });

    const proposal = await Proposal.create({
      sender: req.user._id,
      receiver: receiverId,
      message: message || 'Main aapke saath jeevan bitana chahta/chahti hun.',
    });

    const populated = await proposal.populate(['sender', 'receiver']);
    res.status(201).json(populated);
  } catch (err) {
    if (err.code === 11000) return res.status(400).json({ message: 'Proposal pehle se bheja gaya hai' });
    res.status(500).json({ message: 'Error sending proposal' });
  }
});

// GET /api/proposals/received
router.get('/received', protect, async (req, res) => {
  try {
    const proposals = await Proposal.find({ receiver: req.user._id })
      .populate('sender', '-phone')
      .sort({ createdAt: -1 });
    res.json(proposals);
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

// GET /api/proposals/sent
router.get('/sent', protect, async (req, res) => {
  try {
    const proposals = await Proposal.find({ sender: req.user._id })
      .populate('receiver', '-phone')
      .sort({ createdAt: -1 });
    res.json(proposals);
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

// PUT /api/proposals/:id — Accept or Reject
router.put('/:id', protect, async (req, res) => {
  try {
    const { status } = req.body;
    if (!['accepted', 'rejected'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }
    const proposal = await Proposal.findOne({ _id: req.params.id, receiver: req.user._id });
    if (!proposal) return res.status(404).json({ message: 'Proposal nahi mila' });

    proposal.status = status;
    await proposal.save();
    const populated = await proposal.populate(['sender', 'receiver']);
    res.json(populated);
  } catch (err) {
    res.status(500).json({ message: 'Error' });
  }
});

module.exports = router;
