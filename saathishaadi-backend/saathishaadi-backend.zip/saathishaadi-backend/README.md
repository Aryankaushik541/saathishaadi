# SaathiShaadi Backend

Node.js + Express + MongoDB + Socket.io API

## Setup

```bash
npm install
cp .env.example .env
# .env mein MONGO_URI aur JWT_SECRET set karein
```

## Run

```bash
# Development
npm run dev

# Production
npm start
```

## Seed Dummy Data

```bash
node utils/seed.js
```

This creates 30 dummy users (15 male + 15 female) + sample ads.
- Test phones: `9800000001` to `9800000030`
- Test OTP: `123456`
- Admin: `username=admin`, `password=saathishaadi@admin2025`

## API Endpoints

### Auth
- `POST /api/auth/send-otp` — Send OTP to phone
- `POST /api/auth/verify-otp` — Login with OTP
- `POST /api/auth/register` — Register with OTP (multipart)

### Users (Protected)
- `GET /api/users` — Browse with filters: `?religion=Hindu&gender=Female&district=Patna&minAge=22&maxAge=30&page=1`
- `GET /api/users/:id` — Get profile
- `PUT /api/users/profile` — Update own profile (multipart)

### Proposals (Protected)
- `POST /api/proposals` — Send proposal
- `GET /api/proposals/received` — Received proposals
- `GET /api/proposals/sent` — Sent proposals
- `PUT /api/proposals/:id` — Accept/Reject `{ status: "accepted" }`

### Messages (Protected, only accepted proposals)
- `GET /api/messages/conversations` — All chats
- `GET /api/messages/:userId` — Chat history
- `POST /api/messages` — Send message

### Admin
- `POST /api/admin/login` — Admin login
- `GET /api/admin/dashboard` — Stats
- `GET /api/admin/users` — All users
- `PUT /api/admin/users/:id/block` — Block user
- `PUT /api/admin/users/:id/unblock` — Unblock
- `DELETE /api/admin/users/:id` — Delete user
- `GET /api/admin/ads` — All ads
- `POST /api/admin/ads` — Create ad
- `PUT /api/admin/ads/:id` — Update ad
- `DELETE /api/admin/ads/:id` — Delete ad

### Ads (Public)
- `GET /api/ads?position=sidebar` — Get active ads

## Socket.io Events

### Client → Server
- `join_chat` — Join chat room
- `send_message` — Send message
- `typing` — Typing indicator
- `call_user` — Initiate WebRTC call
- `answer_call` — Accept call
- `end_call` — End call
- `ice_candidate` — ICE candidate exchange

### Server → Client
- `receive_message` — New message
- `user_online` / `user_offline` — Presence
- `typing` — Typing indicator
- `incoming_call` — Someone calling
- `call_accepted` — Call accepted
- `call_ended` — Call ended
- `ice_candidate` — ICE candidate

## Deployment (Render)

1. Push to GitHub
2. New Web Service on Render
3. Set environment variables:
   - `MONGO_URI` — MongoDB Atlas connection string
   - `JWT_SECRET` — Random secret key
   - `FRONTEND_URL` — Vercel frontend URL
   - `ADMIN_URL` — Vercel admin URL
4. Build command: `npm install`
5. Start command: `npm start`

## MongoDB Atlas Setup

1. Go to mongodb.com/atlas
2. Create free cluster
3. Get connection string
4. Replace `<user>:<password>` in MONGO_URI
5. Add IP `0.0.0.0/0` in Network Access
