const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  phone: { type: String, required: true, unique: true, trim: true },
  name: { type: String, required: true, trim: true },
  age: { type: Number, required: true, min: 18, max: 60 },
  gender: { type: String, enum: ['Male', 'Female'], required: true },
  religion: { type: String, required: true },
  caste: { type: String, default: '' },
  district: { type: String, default: '' },
  profession: { type: String, default: '' },
  bio: { type: String, default: '', maxlength: 500 },
  photo: { type: String, default: '' },
  isActive: { type: Boolean, default: true },
  isBlocked: { type: Boolean, default: false },
  isAdmin: { type: Boolean, default: false },
  lastSeen: { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
